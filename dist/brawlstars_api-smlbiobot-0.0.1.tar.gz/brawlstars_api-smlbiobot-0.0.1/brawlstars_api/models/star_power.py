from .base import BaseBrawlStarsModel


class StarPowerModel(BaseBrawlStarsModel):
    id: int
    name: str
